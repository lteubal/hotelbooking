-- MySQL dump 10.13  Distrib 5.7.19, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: booking
-- ------------------------------------------------------
-- Server version	5.7.19-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `creditcard` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(8,2) unsigned NOT NULL,
  `taxes` decimal(8,2) unsigned NOT NULL,
  `fees` decimal(8,2) unsigned NOT NULL,
  `total` decimal(8,2) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (1,'rwer','werwer','rwerew','2345243',0.00,0.00,0.00,0.00,'2017-11-23 06:39:13','2017-11-23 06:39:13'),(2,'ewrwer','werwer','wrewer22222222222222 24532','55555555555555555',0.00,0.00,0.00,0.00,'2017-11-23 06:42:44','2017-11-23 06:42:44'),(3,'dsfjhjkgjhk k','ytutyutyutyu','iuoyiooiuuio','uioiu8979879789',0.00,0.00,0.00,0.00,'2017-11-23 06:44:06','2017-11-23 06:44:06'),(4,'Test','1234','let@gsadf.com','342234234234',0.00,0.00,0.00,0.00,'2017-11-23 13:49:43','2017-11-23 13:49:43'),(5,'Test','1234','let@gsadf.com','342234234234',0.00,0.00,0.00,0.00,'2017-11-23 13:50:37','2017-11-23 13:50:37'),(6,'Test','1234','let@gsadf.com','342234234234',0.00,0.00,0.00,0.00,'2017-11-23 13:51:32','2017-11-23 13:51:32'),(7,'Test','1234','let@gsadf.com','342234234234',0.00,0.00,0.00,0.00,'2017-11-23 13:52:49','2017-11-23 13:52:49'),(8,'Prueba','Nueva','lprueba@.com','3422343242334',0.00,0.00,0.00,0.00,'2017-11-23 13:53:19','2017-11-23 13:53:19'),(9,'Ltewrw','prueba','rerwe@fsdfsd.com','324234234234',0.00,0.00,0.00,0.00,'2017-11-23 14:06:27','2017-11-23 14:06:27'),(10,'sdf','fsdsd','sdfs','fsfdfsd',0.00,0.00,0.00,0.00,'2017-11-23 14:16:38','2017-11-23 14:16:38'),(11,'sdf','fsdsd','sdfs','fsfdfsd',0.00,0.00,0.00,0.00,'2017-11-23 14:20:34','2017-11-23 14:20:34'),(12,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:23:05','2017-11-23 14:23:05'),(13,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:24:09','2017-11-23 14:24:09'),(14,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:26:50','2017-11-23 14:26:50'),(15,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:27:44','2017-11-23 14:27:44'),(16,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:28:19','2017-11-23 14:28:19'),(17,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:28:37','2017-11-23 14:28:37'),(18,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:29:25','2017-11-23 14:29:25'),(19,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:29:37','2017-11-23 14:29:37'),(20,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:30:21','2017-11-23 14:30:21'),(21,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:32:40','2017-11-23 14:32:40'),(22,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:32:54','2017-11-23 14:32:54'),(23,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:33:36','2017-11-23 14:33:36'),(24,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:34:18','2017-11-23 14:34:18'),(25,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:34:37','2017-11-23 14:34:37'),(26,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:39:38','2017-11-23 14:39:38'),(27,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:40:35','2017-11-23 14:40:35'),(28,'sdf','fsdsd','sdfs','fsfdfsddasd',0.00,0.00,0.00,0.00,'2017-11-23 14:41:54','2017-11-23 14:41:54'),(29,'fddfsd','sdfsdf','fsdfsd','sdfsdsdf',0.00,0.00,0.00,0.00,'2017-11-23 14:42:28','2017-11-23 14:42:28');
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-11-23 11:55:16
